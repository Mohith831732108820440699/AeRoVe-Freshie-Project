#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <geometry_msgs/msg/pose_array.hpp>
#include <std_msgs/msg/float32_multi_array.hpp>
#include <std_msgs/msg/string.hpp>
#include <vector>
#include <queue>
#include <cmath>
#include <algorithm>
#include <unordered_map>
#include <chrono>

using std::placeholders::_1;
using namespace std::chrono_literals;

struct Point { float x, y; };

struct GridPoint {
    int x, y;
    bool operator==(const GridPoint& o) const { return x==o.x && y==o.y; }
};

struct GridPointHash {
    std::size_t operator()(const GridPoint& p) const {
        return std::hash<int>()(p.x) ^ (std::hash<int>()(p.y) << 16);
    }
};

struct AStarNode {
    GridPoint pos;
    float g, h, f;
    GridPoint parent;
    bool operator>(const AStarNode& o) const { return f > o.f; }
};

enum class MissionState {
    WAITING_FOR_DATA,
    FLYING_TO_GREEN,
    HOVERING_GREEN,
    FLYING_TO_YELLOW,
    HOVERING_YELLOW,
    FLYING_TO_BLUE,
    MISSION_COMPLETE
};

class AStarPlannerNode : public rclcpp::Node
{
public:
    AStarPlannerNode() : Node("astar_planner")
    {
        // Subscribers
        map_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
            "/binary_grid", 10,
            std::bind(&AStarPlannerNode::map_callback, this, _1));

        circles_sub_ = create_subscription<geometry_msgs::msg::PoseArray>(
            "/circle_coordinates", 10,
            std::bind(&AStarPlannerNode::circles_callback, this, _1));

        event_sub_ = create_subscription<std_msgs::msg::String>(
            "/mission_event", 10,
            std::bind(&AStarPlannerNode::event_callback, this, _1));

        // Publishers
        waypoint_pub_ = create_publisher<std_msgs::msg::Float32MultiArray>(
            "/waypoint_list", 10);

        trigger_pub_ = create_publisher<std_msgs::msg::String>(
            "/mission_trigger", 10);

        // Main planning loop at 1 Hz
        timer_ = create_wall_timer(1000ms,
            std::bind(&AStarPlannerNode::planning_loop, this));

        RCLCPP_INFO(get_logger(), "A* Planner ready — waiting for map and disc positions");
    }

private:
    // State
    MissionState state_ = MissionState::WAITING_FOR_DATA;
    nav_msgs::msg::OccupancyGrid current_map_;
    bool map_received_     = false;
    bool circles_received_ = false;

    // Disc world positions (arena frame)
    float blue_x_   = 5.0, blue_y_   = 1.0;
    float green_x_  = 0.0, green_y_  = 0.0;
    float yellow_x_ = 0.0, yellow_y_ = 0.0;
    bool green_detected_  = false;
    bool yellow_detected_ = false;

    // Drone current position (updated from waypoint arrival events)
    float drone_x_ = 5.0, drone_y_ = 1.0;

    // Hover timer
    rclcpp::Time hover_start_;
    bool hover_started_ = false;

    rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr map_sub_;
    rclcpp::Subscription<geometry_msgs::msg::PoseArray>::SharedPtr circles_sub_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr event_sub_;
    rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr waypoint_pub_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr trigger_pub_;
    rclcpp::TimerBase::SharedPtr timer_;

    // ── Callbacks ────────────────────────────────────────────────────

    void map_callback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
    {
        current_map_ = *msg;
        map_received_ = true;
    }

    void circles_callback(const geometry_msgs::msg::PoseArray::SharedPtr msg)
    {
        if (msg->poses.size() < 3) return;

        // Order: blue[0], green[1], yellow[2]
        // z == -1.0 means not detected
        if (msg->poses[0].position.z >= 0.0) {
            blue_x_ = msg->poses[0].position.x;
            blue_y_ = msg->poses[0].position.y;
        }
        if (msg->poses[1].position.z >= 0.0) {
            green_x_       = msg->poses[1].position.x;
            green_y_       = msg->poses[1].position.y;
            green_detected_ = true;
        }
        if (msg->poses[2].position.z >= 0.0) {
            yellow_x_       = msg->poses[2].position.x;
            yellow_y_       = msg->poses[2].position.y;
            yellow_detected_ = true;
        }
        circles_received_ = true;
    }

    void event_callback(const std_msgs::msg::String::SharedPtr msg)
    {
        std::string event = msg->data;
        RCLCPP_INFO(get_logger(), "Mission event received: %s", event.c_str());

        if (event == "arrived_green" && state_ == MissionState::FLYING_TO_GREEN) {
            state_ = MissionState::HOVERING_GREEN;
            hover_started_ = false;
            drone_x_ = green_x_;
            drone_y_ = green_y_;
            RCLCPP_INFO(get_logger(), "Arrived at green — hovering 3 seconds, dropping payload");
            auto t = std_msgs::msg::String();
            t.data = "drop_payload";
            trigger_pub_->publish(t);
        }
        else if (event == "arrived_yellow" && state_ == MissionState::FLYING_TO_YELLOW) {
            state_ = MissionState::HOVERING_YELLOW;
            hover_started_ = false;
            drone_x_ = yellow_x_;
            drone_y_ = yellow_y_;
            RCLCPP_INFO(get_logger(), "Arrived at yellow — triggering ArUco scan");
            auto t = std_msgs::msg::String();
            t.data = "scan_aruco";
            trigger_pub_->publish(t);
        }
        else if (event == "arrived_blue" && state_ == MissionState::FLYING_TO_BLUE) {
            state_ = MissionState::MISSION_COMPLETE;
            RCLCPP_INFO(get_logger(), "Mission complete! Drone landed at base.");
            auto t = std_msgs::msg::String();
            t.data = "mission_complete";
            trigger_pub_->publish(t);
        }
    }

    // ── Planning loop ────────────────────────────────────────────────

    void planning_loop()
    {
        switch (state_) {

        case MissionState::WAITING_FOR_DATA:
            if (!map_received_) {
                RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 3000,
                    "Waiting for occupancy grid...");
                return;
            }
            if (!circles_received_ || !green_detected_) {
                RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 3000,
                    "Waiting for disc positions from camera...");
                return;
            }
            RCLCPP_INFO(get_logger(),
                "Data ready. Green=(%.2f,%.2f) Yellow=(%.2f,%.2f) Blue=(%.2f,%.2f)",
                green_x_, green_y_, yellow_x_, yellow_y_, blue_x_, blue_y_);
            state_ = MissionState::FLYING_TO_GREEN;
            send_path_to({drone_x_, drone_y_}, {green_x_, green_y_}, 5.0);
            break;

        case MissionState::HOVERING_GREEN: {
            if (!hover_started_) {
                hover_start_   = now();
                hover_started_ = true;
            }
            double elapsed = (now() - hover_start_).seconds();
            if (elapsed >= 3.0) {
                RCLCPP_INFO(get_logger(), "Hover done — flying to yellow");
                state_ = MissionState::FLYING_TO_YELLOW;
                send_path_to({drone_x_, drone_y_}, {yellow_x_, yellow_y_}, 5.0);
            }
            break;
        }

        case MissionState::HOVERING_YELLOW: {
            if (!hover_started_) {
                hover_start_   = now();
                hover_started_ = true;
            }
            double elapsed = (now() - hover_start_).seconds();
            if (elapsed >= 5.0) {
                RCLCPP_INFO(get_logger(), "Scan done — flying back to blue");
                state_ = MissionState::FLYING_TO_BLUE;
                send_path_to({drone_x_, drone_y_}, {blue_x_, blue_y_}, 5.0);
            }
            break;
        }

        case MissionState::FLYING_TO_GREEN:
        case MissionState::FLYING_TO_YELLOW:
        case MissionState::FLYING_TO_BLUE:
        case MissionState::MISSION_COMPLETE:
            break;
        }
    }

    // ── Path computation and publishing ──────────────────────────────

    void send_path_to(Point start, Point goal, float altitude)
    {
        RCLCPP_INFO(get_logger(),
            "Planning path (%.2f,%.2f) → (%.2f,%.2f)",
            start.x, start.y, goal.x, goal.y);

        std::vector<Point> path = run_a_star(start, goal);

        if (path.empty()) {
            RCLCPP_WARN(get_logger(), "A* found no path — sending direct waypoint");
            path.push_back(goal);
        }

        std_msgs::msg::Float32MultiArray msg;
        for (auto& p : path) {
            msg.data.push_back(p.x);
            msg.data.push_back(p.y);
            msg.data.push_back(altitude);
        }
        waypoint_pub_->publish(msg);
        RCLCPP_INFO(get_logger(), "Published %zu waypoints", path.size());
    }

    // ── Coordinate helpers ───────────────────────────────────────────

    GridPoint worldToGrid(float wx, float wy) {
        return {
            static_cast<int>((wx - current_map_.info.origin.position.x)
                             / current_map_.info.resolution),
            static_cast<int>((wy - current_map_.info.origin.position.y)
                             / current_map_.info.resolution)
        };
    }

    Point gridToWorld(GridPoint gp) {
        return {
            gp.x * current_map_.info.resolution + current_map_.info.origin.position.x,
            gp.y * current_map_.info.resolution + current_map_.info.origin.position.y
        };
    }

    bool isValid(GridPoint p) {
        if (p.x < 0 || p.x >= (int)current_map_.info.width ||
            p.y < 0 || p.y >= (int)current_map_.info.height)
            return false;
        int idx = p.x + p.y * current_map_.info.width;
        return current_map_.data[idx] <= 50;
    }

    // ── A* ───────────────────────────────────────────────────────────

    std::vector<Point> run_a_star(Point start_w, Point goal_w)
    {
        std::vector<Point> path;
        GridPoint start = worldToGrid(start_w.x, start_w.y);
        GridPoint goal  = worldToGrid(goal_w.x,  goal_w.y);

        if (!isValid(start)) {
            RCLCPP_WARN(get_logger(), "Start is in obstacle — nudging");
            // Try small offsets to escape
            bool found = false;
            for (int dx = -2; dx <= 2 && !found; dx++)
                for (int dy = -2; dy <= 2 && !found; dy++) {
                    GridPoint s2 = {start.x+dx, start.y+dy};
                    if (isValid(s2)) { start = s2; found = true; }
                }
            if (!found) return path;
        }
        if (!isValid(goal)) {
            RCLCPP_WARN(get_logger(), "Goal is in obstacle");
            return path;
        }

        std::priority_queue<AStarNode,std::vector<AStarNode>,std::greater<AStarNode>> open;
        std::unordered_map<GridPoint,float,GridPointHash> g_scores;
        std::unordered_map<GridPoint,GridPoint,GridPointHash> parents;

        AStarNode s;
        s.pos = start; s.g = 0;
        s.h = std::hypot(goal.x-start.x, goal.y-start.y);
        s.f = s.h; s.parent = {-1,-1};
        open.push(s);
        g_scores[start] = 0;

        int dx[] = {1,1,0,-1,-1,-1,0,1};
        int dy[] = {0,1,1,1,0,-1,-1,-1};

        while (!open.empty()) {
            AStarNode cur = open.top(); open.pop();

            if (cur.pos == goal) {
                GridPoint c = goal;
                while (!(c == start)) {
                    path.push_back(gridToWorld(c));
                    c = parents[c];
                }
                path.push_back(gridToWorld(start));
                std::reverse(path.begin(), path.end());

                // Downsample — keep every 5th waypoint to reduce noise
                std::vector<Point> sparse;
                for (size_t i = 0; i < path.size(); i++)
                    if (i % 5 == 0 || i == path.size()-1)
                        sparse.push_back(path[i]);
                return sparse;
            }

            for (int i = 0; i < 8; i++) {
                GridPoint nb = {cur.pos.x+dx[i], cur.pos.y+dy[i]};
                if (!isValid(nb)) continue;
                float move = (dx[i]==0||dy[i]==0) ? 1.0f : 1.414f;
                float tg   = g_scores[cur.pos] + move;
                if (g_scores.find(nb)==g_scores.end() || tg < g_scores[nb]) {
                    g_scores[nb] = tg;
                    parents[nb]  = cur.pos;
                    AStarNode n;
                    n.pos = nb; n.g = tg;
                    n.h = std::hypot(goal.x-nb.x, goal.y-nb.y);
                    n.f = tg + n.h;
                    open.push(n);
                }
            }
        }
        RCLCPP_WARN(get_logger(), "A* found no path");
        return path;
    }
};

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<AStarPlannerNode>());
    rclcpp::shutdown();
    return 0;
}
